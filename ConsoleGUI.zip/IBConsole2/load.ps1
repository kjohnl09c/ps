﻿#Set Execution Policy
Set-ExecutionPolicy RemoteSigned

#Add the Presntation Framework to the script so that the WPF objects can run from 
#the powershell console
Add-Type -AssemblyName PresentationCore, PresentationFramework, System.Drawing, System.Windows.Forms


#########################################################################
#FUNCTIONS
#########################################################################
Function test_server( $name )
{

    $result = Test-Connection $name

    if( $result.ReplySize -eq 32 )
    {
        $connection = $true
    
    } else {

        $connection = $false
    }
        
    return $connection

}

Function update_xaml( $myWindow )
{
    $Global:progBar.Value = 20
    $myWindow.Dispatcher.Invoke([action]{},"Render")
    Start-Sleep -Seconds 2
    $Global:progBar.Value = 40
    $myWindow.Dispatcher.Invoke([action]{},"Render")
    Start-Sleep -Seconds 2
    $Global:progBar.Value = 60
    $myWindow.Dispatcher.Invoke([action]{},"Render")
    Start-Sleep -Seconds 2
    $Global:progBar.Value = 80
    $myWindow.Dispatcher.Invoke([action]{},"Render")
    Start-Sleep -Seconds 2
    $Global:progBar.Value = 100
    $myWindow.Dispatcher.Invoke([action]{},"Render")
    #$myWindow.Close()
    return

}

#########################################################################
#SET PATHS TO RESOURCES
#########################################################################
$location = Split-Path $MyInvocation.MyCommand.Path -Parent

<#
Write-Host "############################################################################"
Write-Host "Resource Paths:"
Write-Host "Root Location is:           $location"
Write-Host "File Folder Path is:        $location\file"
Write-Host "Images Folder Path is:      $location\images"
Write-Host "Power Shell Folder Path is: $location\ps"
Write-Host "XML Folder Path is:         $location\xml"
#>

$root = $location
$fileRoot = $location + "\file"
$imageRoot = $location + "\images"
$psRoot = $location + "\ps"
$xmlRoot = $location + "\xml"


#########################################################################
#INCLUDED FILES
#########################################################################
$load_include = $root + "\include.ps1"
. $load_include

#########################################################################
#LOAD XAML CODE FROM FILE
#########################################################################
$load_xaml = $xmlRoot + "\load.xml"
[xml]$xaml = Get-Content -Path $load_xaml

##########################################################################
# READ THE CONTENTS OF THE SERVER NAMES FROM THE FILE
##########################################################################
$load_file = $fileRoot + "\dhcp_servers.txt"
$content_file = Get-Content -Path $load_file

#########################################################################
#CREATE THE WINDOW
#########################################################################
$Window = create_window $xaml

#########################################################################
#PS TO XAML IMAGE LINK
#########################################################################
$Global:loadImage = $Window.FindName('Home')
$Global:progBar = $Window.FindName('Pbar')

#########################################################################
#SET LOAD IMAGE
#########################################################################
$Global:loadImage.Source = $imageRoot + "\gray868x1550.png"

#########################################################################
#MAIN
#########################################################################
$x = Start-Job -FilePath .\bgJob.ps1 
update_xaml $Window
$file = Receive-Job -Id $x.Id
$file | Out-File -FilePath "test.xml"
update_xaml $Window
$Window.Close()

<#
$sb1 = {
    .\psworkingdir\applications\IBConsole2\pbar.ps1 -Window $Window -content $content_file -progBar $Global:progBar
    }

$job = Start-Job -ScriptBlock $sb1
Receive-Job $job
#>

<#
$Global:progBar.Value = 20
$Window.Dispatcher.Invoke([action]{},"Render")
Start-Sleep -Seconds 2
$Global:progBar.Value = 40
$Window.Dispatcher.Invoke([action]{},"Render")
Start-Sleep -Seconds 2
$Global:progBar.Value = 60
$Window.Dispatcher.Invoke([action]{},"Render")
Start-Sleep -Seconds 2
$Global:progBar.Value = 80
$Window.Dispatcher.Invoke([action]{},"Render")
Start-Sleep -Seconds 2
$Global:progBar.Value = 100
$Window.Dispatcher.Invoke([action]{},"Render")
$Window.Close()
#>



#$Window.Dispatcher.Invoke([action]{},"Render")



#########################################################################
#SHOW THE WINDOW
#########################################################################
#Display the Window
#$Window.ShowDialog() | Out-Null


#$Global:progBar.Value = 50
#[System.Windows.Forms.Application]::DoEvents()
#$Window.Dispatcher.Invoke()
#$Window.Dispatcher.Invoke([action]{},"Render")