﻿$conn = Test-Connection -ComputerName jaxdhcp1
$stat1 = $conn.ReplySize[0]
$stat1

$conn = Test-Connection -ComputerName phldhcp1
$stat2 = $conn.ReplySize[0]
$stat2