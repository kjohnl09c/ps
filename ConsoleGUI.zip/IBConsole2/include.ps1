﻿Function create_window( $xaml )
{

    $reader=(New-Object System.Xml.XmlNodeReader $xaml )

    $Window=[Windows.Markup.XamlReader]::Load( $reader )

    return $Window
}

Function refresh_window($window)
{





}