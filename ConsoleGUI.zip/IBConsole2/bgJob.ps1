﻿#Set Execution Policy
Set-ExecutionPolicy RemoteSigned

#Add the Presntation Framework to the script so that the WPF objects can run from 
#the powershell console
Add-Type -AssemblyName PresentationCore, PresentationFramework

#Load xaml from file
[xml]$xaml = Get-Content .\test2.xml

#########################################################################
#XML Node Reader
#########################################################################
#Pass the xaml data/code to the newly created System Object XMLNodeReader
$reader=(New-Object System.Xml.XmlNodeReader $xaml)
$Window=[Windows.Markup.XamlReader]::Load($reader)




#########################################################################
#Display the Window
#########################################################################
$Window.ShowDialog() | Out-Null



























#$file = Get-Content -Path C:\psworkingdir\applications\IBConsole2\xaml.txt
#$file | % { $_.Replace("x:Name=`"jaxdhcp1`" Background=`"LightGreen`"", "x:Name=`"jaxdhcp1`" Background=`"Red`"") } | Set-Content C:\psworkingdir\applications\IBConsole2\xaml.txt
#$file | % { $_.Replace("x:Name=`"jaxdhcp1`"", "x:Name=`"jaxdhcp1`" Background=`"LightGreen`"") } | Set-Content C:\psworkingdir\applications\IBConsole2\xaml.txt
#Test-Connection -ComputerName jaxdhcp1
#Test-Connection -ComputerName jaxvndhcp1
#Test-Connection -ComputerName phldhcp1
#Test-Connection -ComputerName phlvndhcp1